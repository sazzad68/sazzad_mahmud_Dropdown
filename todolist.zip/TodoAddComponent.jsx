import React from 'react';

export default class TodoAddComponent extends React.Component {

    render() {
        return (
            <button type="submit">Add</button>
        );
    }
}
